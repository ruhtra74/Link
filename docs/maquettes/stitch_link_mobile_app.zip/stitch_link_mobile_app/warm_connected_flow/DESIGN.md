---
name: Warm Connected Flow
colors:
  surface: '#fff8f5'
  surface-dim: '#e0d8d5'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2ee'
  surface-container: '#f4ece8'
  surface-container-high: '#eee7e3'
  surface-container-highest: '#e9e1dd'
  on-surface: '#1e1b19'
  on-surface-variant: '#55433b'
  inverse-surface: '#33302d'
  inverse-on-surface: '#f7efeb'
  outline: '#89726a'
  outline-variant: '#dcc1b7'
  surface-tint: '#9a451a'
  primary: '#6a2600'
  on-primary: '#ffffff'
  primary-container: '#8b3a0f'
  on-primary-container: '#ffb596'
  inverse-primary: '#ffb596'
  secondary: '#a83900'
  on-secondary: '#ffffff'
  secondary-container: '#fc6018'
  on-secondary-container: '#531800'
  tertiary: '#652a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#8a3c00'
  on-tertiary-container: '#ffb68e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7b2f03'
  secondary-fixed: '#ffdbcf'
  secondary-fixed-dim: '#ffb59a'
  on-secondary-fixed: '#380d00'
  on-secondary-fixed-variant: '#802a00'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#773300'
  background: '#fff8f5'
  on-background: '#1e1b19'
  surface-variant: '#e9e1dd'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 2.5rem
---

## Brand & Style

Ce design system pour l'application mobile LINK incarne l'interaction sociale organique, le réseau et l'énergie collective. Inspiré par les formes douces, interconnectées et généreuses de l'identité visuelle (symbolisée par le nœud central et ses satellites), l'univers allie modernité fonctionnelle, chaleur tactile et précision contemporaine.

L'expérience visuelle conjugue :
- **Modernisme chaleureux :** Une base d'affichage sobre et contrastée (noirs profonds, blanc pur et crème subtil) dynamisée par la richesse d'un brun-caramel terrien associé à des touches vives d'ambre et d'orange énergique.
- **Formes douces & connectivité :** Des courbures équilibrées qui font écho aux bulles de connexions et aux terminaux arrondis du logo, sans tomber dans l'infantile grâce à une rigueur typographique géométrique.
- **Clarté mobile :** Densité adaptée au pouce, micro-interactions nettes, repères visuels instantanés et contraste garanti en environnement lumineux comme nocturne.

## Colors

La palette combine des tons terreux profonds issus de l'identité de marque et un éclat dynamique pour hiérarchiser l'information sur mobile :

- **Primary (`#8B3A0F` - Brun Caramel Logo) :** Couleur totem et institutionnelle. Utilisée pour les titres d'ancrage, les états sélectionnés clés, les avatars principaux et les illustrations de nœuds.
- **Secondary (`#E65100` - Orange Vif Solaire) :** Accent d'action primaire et d'urgence positive. Dédié aux Call to Action (CTA), badges de notifications non lues, indicateurs d'état actif et boutons flottants.
- **Tertiary (`#C25E1A` - Ambre Fauve) :** Teinte de transition pour les dégradés d'accentuation, les puces d'états secondaires, les icônes interactives et les bordures de focus subtiles.
- **Neutral (`#1C1917` & `#121212` - Noir Pierre) :** Structure typographique, fonds contrastés et conteneurs sombres. En mode clair, `#1C1917` assure un contraste parfait de lecture tout en adoucissant le noir pur.
- **Surfaces & Fondations :** 
  - Background principal : `#FAF8F5` (un blanc cassé coquille d'œuf chaud qui résonne avec le fond du logo).
  - Background surface élevée / Card : `#FFFFFF`.
  - Sub-neutral bordures et séparateurs : `#E7E5E4` et `#D6D3D1`.

## Typography

Le système utilise **Plus Jakarta Sans** sur l'ensemble des niveaux textuels. Ses terminaux légèrement arrondis, ses proportions géométriques ouvertes et ses finitions contemporaines prolongent l'esprit convivial du logo LINK tout en garantissant une lisibilité clinique sur les interfaces mobiles denses.

Règles de hiérarchie :
- **Headlines & Display :** Utilisés en graisses Heavy (`700` et `800`) pour donner de la corpulence et de l'autorité aux accroches et en-têtes d'écrans.
- **Body :** Graisse Regular (`400`) avec une hauteur de ligne généreuse pour prévenir la fatigue oculaire lors de flux de messages ou de listes de contacts.
- **Labels & Micro-copies :** Graisses Medium (`500`) et SemiBold (`600`) calibrées pour les onglets, légendes, tags et éléments de formulaires.

## Layout & Spacing

Le layout repose sur une structure fluide optimisée pour l'ergonomie tactile au pouce (Thumb Zone) :
- **Marges mobiles standard :** `16px` (`margin: 1rem`) assurant une respiration suffisante par rapport aux bordures physiques de l'écran.
- **Gouttières (Gutters) :** `12px` (`0.75rem`) sur les listes doubles colonnes ou vignettes d'utilisateurs.
- **Grille de rythme :** Base 4px / 8px stricte régissant les hauteurs tactiles (minimum 44x44px pour les zones cliquables) et l'espacement intérieur des cartes et cellules.
- **Adaptation tablette :** Marges élargies à `24px` (`1.5rem`), passage à une grille de 6 à 12 colonnes avec contrainte de largeur maximale centrale à 680px pour les flux de lecture.

## Elevation & Depth

Le parti pris d'élévation évite les ombres froides génériques pour privilégier des ombres subtilement teintées d'ambre chaud et des superpositions de surfaces contrastées :

- **Niveau 0 (Base / Canvas) :** Fond `#FAF8F5`. Zéro élévation.
- **Niveau 1 (Cards, Modules, Input Groups) :** Surface `#FFFFFF` avec une bordure légère `1px solid #F0EDE8` et une ombre diffuse tiède : `box-shadow: 0 2px 8px -2px rgba(139, 58, 15, 0.05)`.
- **Niveau 2 (Boutons flottants, Menus contextuels, Dropdowns) :** `box-shadow: 0 8px 20px -4px rgba(139, 58, 15, 0.12), 0 2px 6px -1px rgba(28, 25, 23, 0.04)`.
- **Niveau 3 (Bottom Sheets, Modales, Notifications persistantes) :** Arrière-plan dépoli `backdrop-filter: blur(12px)` avec fond `rgba(255, 255, 255, 0.92)` ou fond plein élevé avec ombre douce expansive `0 16px 32px -8px rgba(28, 25, 23, 0.16)`.

## Shapes

La géométrie des composants adopte l'échelle `Rounded` (indice 2), reflétant la douceur organique du lettrage et des connecteurs circulaires de LINK :
- **Rayon standard (`rounded-md`, 0.5rem / 8px) :** Champs de saisie, selects, checkboxes, petites cartes de données.
- **Rayon large (`rounded-lg`, 1rem / 16px) :** Cartes de flux, conteneurs de contenu, bulles de dialogue, bottom sheets.
- **Rayon complet (Pill / 9999px) :** Boutons d'action principale, badges, tags filtrants, barres de recherche flottantes et toggles switches.

## Components

### Boutons
- **Primary Action (CTA) :** Fond `#E65100` (Orange vif), typographie en `label-lg` blanc (`#FFFFFF`), forme en pilule (`rounded-full`), padding vertical `12px` et horizontal `24px`. Au press : léger assombrissement vers `#C25E1A` avec scale à `0.98`.
- **Brand Secondary :** Fond `#8B3A0F`, texte `#FFFFFF`. Réservé aux actions clés institutionnelles ou aux parcours de mise en relation.
- **Outline / Ghost :** Fond transparent, bordure `1.5px solid #8B3A0F` ou `#1C1917`, texte de couleur correspondante.
- **Tonal / Soft :** Fond `rgba(230, 81, 0, 0.10)`, texte `#C25E1A`. Idéal pour les actions secondaires directes.

### Champs de saisie (Inputs & Selects)
- **Structure :** Hauteur minimale `48px`, fond `#FFFFFF` ou `#F5F2EB`, bordure `1px solid #E7E5E4`, rayon `12px` (`rounded-md`).
- **Typographie :** Valeur saisie en `#1C1917` (`body-md`), placeholder en `#A8A29E`.
- **Focus State :** Bordure passant à `#E65100` avec anneau de diffusion externe `0 0 0 3px rgba(230, 81, 0, 0.15)`.
- **Selects :** Même traitement avec chevron orienté vers le bas teinté en `#8B3A0F`.

### Toggles & Switches
- **Piste (Track) :** `48px x 28px`, forme pilule. Éteint : fond `#E7E5E4`. Allumé : fond vibrant `#E65100` ou `#8B3A0F`.
- **Curseur (Thumb) :** Cercle `#FFFFFF` de `22px`, centré avec micro-ombre `0 2px 4px rgba(0,0,0,0.15)`.

### Badges & Chips
- **Chips filtrants :** Rayon pilule, fond `#F5F2EB`, bordure `1px solid #E7E5E4`, texte `#1C1917`. En sélection : fond `#8B3A0F`, texte `#FFFFFF`, bordure `#8B3A0F`.
- **Badges de statut / Notification :** Forme circulaire ou pilule compacte, fond `#E65100`, texte `#FFFFFF` en `label-sm` gras.

### Checkboxes & Radios
- **Checkbox :** Carré adouci (`rounded: 6px`), taille 20x20px, bordure `1.5px solid #D6D3D1`. Lorsque cochée : fond `#8B3A0F`, coche blanche pleine au centre.
- **Radio :** Cercle 20x20px. Lorsque sélectionné : anneau externe `#8B3A0F` avec pastille centrale pleine `#8B3A0F` de 10px.

### Cartes (Cards)
- **Base Card :** Fond `#FFFFFF`, bordure fine `#F0EDE8`, padding `16px` (`space-md`), arrondi `16px` (`rounded-lg`).
- **Interactive Card :** Élévation niveau 1, transition fluide au toucher avec feedback d'activation immédiat.
- **Featured / Connection Card :** Accompagnée d'une ligne d'accentuation supérieure ou latérale aux teintes `#C25E1A` ou de nœuds graphiques en filigrane.

### Nœuds et indicateurs de réseau (Spécifique LINK)
- **Connection Node Avatar :** Avatar profil encapsulé dans un cerclage de 2px couleur `#8B3A0F`, relié par des filets de connexion vectoriels semi-transparents (`rgba(139, 58, 15, 0.25)`).